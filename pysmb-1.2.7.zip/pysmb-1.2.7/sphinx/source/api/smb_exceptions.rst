
SMB Exceptions
==============

.. autoclass:: smb.base.SMBTimeout
    :members:

.. autoclass:: smb.base.NotReadyError
    :members:

.. autoclass:: smb.base.NotConnectedError
    :members:

.. autoclass:: smb.smb_structs.UnsupportedFeature
    :members:

.. autoclass:: smb.smb_structs.ProtocolError
    :members:

.. autoclass:: smb.smb_structs.OperationFailure
    :members:
